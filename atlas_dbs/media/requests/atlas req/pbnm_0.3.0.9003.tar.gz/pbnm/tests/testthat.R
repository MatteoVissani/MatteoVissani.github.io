library(testthat)
library(pbnm)
library(Matrix) # needed by lme4
library(lme4)

test_check("pbnm")
