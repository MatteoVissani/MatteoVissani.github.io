#' pbnm: Parametric Bootstrap Test of Nested Models
#' 
#' The main function is pbnm, which and returns a "pbnm" object.
#' The boot strap generates the distribution for a single model 
#' parameter (if the two models differ by only one parameter) and also
#' for one of the following tests of nested models:
#' likelihood ratio, restricted likelihood ratio, or F.
#' The summary, confint, and plot functions are supported for
#' "pbnm" objects.
#' 
#' @docType package
#' @name pbnm
NULL
