#' Generated data set. It is used in pbnm examples.
#' 
#' @format A data frame with 100 observations.
#' \describe{
#'   \item{y}{linear response variable}
#'   \item{bin}{binarry response variable}
#'   \item{x1}{continuous variable}
#'   \item{x2}{continuous variable}
#'   \item{g1}{factor variable with 12 levels}
#'   \item{g2}{factor variable with 7 levels}
#' }
#' @docType data
#' @keywords datasets
#' @name pbDat
#' @usage data(pbDat)
#' @format A data frame with 100 rows and 6 variables
#' @examples
#' data(pbDat) 
NULL
